# Interest Calculator Website

A clean, responsive web-based Interest Calculator using HTML, CSS, and JavaScript.

## Features
- Simple UI
- Supports:
  - Simple Interest
  - Compound Interest
  - Time in months or years
  - Compound frequency (Yearly, Quarterly, Monthly)
- Input validation
- Modern card-style design

## How to Run Locally
1. Download all files.
2. Keep them in the same folder.
3. Open `index.html` in a browser.

## GitHub Pages Deployment
1. Create repo → upload files
2. Go to Settings → Pages
3. Select branch `main` and root folder
4. Save and get your live URL
