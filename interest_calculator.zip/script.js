function calculate() {
    let principal = document.getElementById("principal").value;
    let rate = document.getElementById("rate").value;
    let time = document.getElementById("time").value;
    let timeType = document.querySelector('input[name="timeType"]:checked').value;
    let interestType = document.getElementById("interestType").value;
    let frequency = document.getElementById("frequency").value;

    let error = document.getElementById("error");

    if (!principal || !rate || !time) {
        error.innerText = "Please fill all fields!";
        return;
    }
    error.innerText = "";

    if (timeType === "months") {
        time = time / 12;
    }

    let totalInterest = 0;
    let totalAmount = 0;

    if (interestType === "simple") {
        totalInterest = (principal * rate * time) / 100;
        totalAmount = Number(principal) + totalInterest;
    } else {
        let n = Number(frequency);
        totalAmount = principal * Math.pow((1 + (rate / 100) / n), n * time);
        totalInterest = totalAmount - principal;
    }

    document.getElementById("totalInterest").innerText = totalInterest.toFixed(2);
    document.getElementById("totalAmount").innerText = totalAmount.toFixed(2);
}